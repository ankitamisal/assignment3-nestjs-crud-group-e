import { IsString } from 'class-validator';

export class create_stud_sub_Dto {
  id: number;

  studentMid: number;

  subjectsId: number;
}
